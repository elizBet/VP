package edu.bsu.logic;

import edu.bsu.entity.User;
import edu.bsu.logic.email.EmailLogic;
import edu.bsu.logic.password.PasswordLogic;
import edu.bsu.logic.username.UserNameLogic;

import java.util.List;

public class ProcessingLogic {
    public static void processList(List<User> users) {
        PasswordLogic.deleteNotValidPasswords(users);
        UserNameLogic.deleteDuplicates(users);
        EmailLogic.emailToLowerCase(users);
    }
}
