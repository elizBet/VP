package edu.bsu.logic.password;

import edu.bsu.entity.User;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static edu.bsu.constants.ApplicationConstants.MIN_LENGTH_OF_PASSWORD;
import static edu.bsu.constants.ApplicationConstants.PATTERN_FOR_SPECIAL_SYMBOLS;
import static edu.bsu.constants.ApplicationConstants.PATTERN_FOR_UPPERCASE_SYMBOLS;

public class PasswordLogic {
    public static void deleteNotValidPasswords(List<User> users) {
        List<User> usersToDelete = new ArrayList<>();
        users.forEach(e -> {
            String password = e.getPassword();
            if (!(validatePasswordByLength(password) && validatePasswordBySpecialSymbols(password)
                    && validatePasswordByUpperCase(password))) {
                usersToDelete.add(e);
            }
        });
        users.removeAll(usersToDelete);
    }

    public static boolean validatePasswordByLength(String password) {
        return password.length() >= MIN_LENGTH_OF_PASSWORD;
    }

    public static boolean validatePasswordBySpecialSymbols(String password) {
        Pattern pattern = Pattern.compile(PATTERN_FOR_SPECIAL_SYMBOLS);
        Matcher matcher = pattern.matcher(password);
        return matcher.find();
    }

    public static boolean validatePasswordByUpperCase(String password) {
        Pattern pattern = Pattern.compile(PATTERN_FOR_UPPERCASE_SYMBOLS);
        Matcher matcher = pattern.matcher(password);
        return matcher.find();
    }
}
