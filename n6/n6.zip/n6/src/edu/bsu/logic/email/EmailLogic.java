package edu.bsu.logic.email;

import edu.bsu.entity.User;

import java.util.List;

public class EmailLogic {
    public static void emailToLowerCase(List<User> users) {
        users.forEach(e->{
            e.setEmail(e.getEmail().toLowerCase());
        });
    }
}
