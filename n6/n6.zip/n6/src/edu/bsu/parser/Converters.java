package edu.bsu.parser;

import edu.bsu.entity.User;

import static edu.bsu.constants.ApplicationConstants.EMAIL_IN_FILE_POSITION;
import static edu.bsu.constants.ApplicationConstants.USERNAME_IN_FILE_POSITION;
import static edu.bsu.constants.ApplicationConstants.PASSWORD_IN_FILE_POSITION;
import static edu.bsu.constants.ApplicationConstants.FILE_DELIMITER;


public class Converters {
    public static User parseToUser(String line) {
        String[] params = line.split(FILE_DELIMITER);
        User user = new User();
        try {
            user.setUsername(params[USERNAME_IN_FILE_POSITION]);
            user.setPassword(params[PASSWORD_IN_FILE_POSITION]);
            user.setEmail(params[EMAIL_IN_FILE_POSITION]);
        } catch (IndexOutOfBoundsException e) {
            System.err.println(e.getMessage());
        }
        return user;
    }

    public static String convertUserToLine(User user){
        String line=user.getUsername()+FILE_DELIMITER+user.getPassword()+FILE_DELIMITER+user.getEmail();
        return line;
    }
}
