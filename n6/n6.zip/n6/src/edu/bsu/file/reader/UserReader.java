package edu.bsu.file.reader;

import edu.bsu.entity.User;
import edu.bsu.parser.Converters;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class UserReader {

    public static List<User> bindToUser(String filePath) {
        List<User> users = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                users.add(Converters.parseToUser(line));
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
        return users;
    }
}
