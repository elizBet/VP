package edu.bsu.constants;

public class ApplicationConstants {
    public final static int USERNAME_IN_FILE_POSITION=0;
    public final static int PASSWORD_IN_FILE_POSITION=1;
    public final static int EMAIL_IN_FILE_POSITION=2;


    public final static int MIN_LENGTH_OF_PASSWORD=8;
    public final static String PATTERN_FOR_SPECIAL_SYMBOLS="#|@|-";
    public final static String PATTERN_FOR_UPPERCASE_SYMBOLS="([A-Z])";
    public final static String FILE_DELIMITER=",";
}
