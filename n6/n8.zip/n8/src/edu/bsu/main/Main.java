package edu.bsu.main;

import edu.bsu.entity.User;
import edu.bsu.file.reader.UserReader;
import edu.bsu.file.writer.UserWriter;
import edu.bsu.logic.ProcessingLogic;

import java.util.List;

public class Main {

    public static void main(String[] args) {
        List<User> masOfUsers = UserReader.bindToUser("data/input.txt");
        ProcessingLogic.processList(masOfUsers);
        UserWriter.writeUsersToFile(masOfUsers,"data/output.txt");
    }
}