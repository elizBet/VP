package edu.bsu.file.writer;

import edu.bsu.entity.User;
import edu.bsu.parser.Converters;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

public class UserWriter {
    public static void writeUsersToFile(List<User> users,String filePath) {
        File file = new File(filePath);
        checkFile(file);

        try (BufferedWriter writer=new BufferedWriter(new FileWriter(file,false))){
            writer.write(getDateToWrite(users));
        }
        catch (IOException e){
            System.err.println(e.getMessage());
        }

    }

    private static void checkFile(File file){
        try {
            if (!file.exists()) {
                file.createNewFile();
            }
        } catch (IOException e) {
            System.err.println(e.getMessage());
        }
    }

    private static String getDateToWrite(List<User> users){
        StringBuilder dataToWrite=new StringBuilder();
        users.forEach(e->{
            dataToWrite.append(Converters.convertUserToLine(e)+"\n");
        });
        return dataToWrite.toString();
    }
}
