package edu.bsu.comparators;

import edu.bsu.entity.User;

import java.util.Comparator;

public class UserNameComparator implements Comparator<User> {

    @Override
    public int compare(User user1, User user2) {
        return user1.getUsername().compareTo(user2.getUsername());
    }
}
