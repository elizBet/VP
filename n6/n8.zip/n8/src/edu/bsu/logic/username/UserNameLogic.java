package edu.bsu.logic.username;

import edu.bsu.comparators.UserNameComparator;
import edu.bsu.entity.User;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

public class UserNameLogic {
    public static void deleteDuplicates(List<User> users) {
        Set<User> usersSet = new TreeSet<>(new UserNameComparator());
        users.forEach(e -> usersSet.add(e));
        users.clear();
        users.addAll(new ArrayList<>(usersSet));
    }
}
